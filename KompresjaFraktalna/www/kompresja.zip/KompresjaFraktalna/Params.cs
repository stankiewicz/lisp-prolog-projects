using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace KompresjaFraktalna {
	[Serializable]
	public class Params {
		float a, k, d, l, e, g, h, m;

		public float A {
			get { return a; }
			set { a = value; }
		}

		public float K {
			get { return k; }
			set { k = value; }
		}

		public float D {
			get { return d; }
			set { d = value; }
		}

		public float L {
			get { return l; }
			set { l = value; }
		}

		public float E {
			get { return e; }
			set { e = value; }
		}

		public float G {
			get { return g; }
			set { g = value; }
		}

		public float H {
			get { return h; }
			set { h = value; }
		}

		public float M {
			get { return m; }
			set { m = value; }
		}

		internal void serialize(System.IO.BinaryWriter bw) {
			bw.Write(this.a);
			bw.Write(this.d);
			bw.Write(this.e);
			bw.Write(this.g);
			bw.Write(this.h);
			bw.Write(this.k);
			bw.Write(this.l);
			bw.Write(this.m);
		}

		public static Params deserialize(BinaryReader br) {
			Params p = new Params();
            p.a = (float)br.ReadDouble();
            p.d = (float)br.ReadDouble();
            p.e = (float)br.ReadDouble();
            p.g = (float)br.ReadDouble();
            p.h = (float)br.ReadDouble();
            p.k = (float)br.ReadDouble();
            p.l = (float)br.ReadDouble();
            p.m = (float)br.ReadDouble();
			return p;
		}
	}
}
